//
//  RecipeApp_iOSApp.swift
//  RecipeApp-iOS
//
//  Created by Gabe Nunez on 12/2/21 
//

import SwiftUI

@main
struct RecipeApp_iOSApp: App {
    var body: some Scene {
        WindowGroup {
            RecipeCategoryListScreen()
        }
    }
}
